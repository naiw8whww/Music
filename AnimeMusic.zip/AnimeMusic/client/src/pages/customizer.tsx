import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Waveform } from "@/components/ui/waveform";
import { ParticleSystem } from "@/components/ui/particle-system";
import { AudioSourceSelector } from "@/components/ui/audio-source-selector";
import { VisualizerSettings } from "@/components/visualizer-settings";
import { ParticleSettings } from "@/components/particle-settings";
import { BackgroundSettings } from "@/components/background-settings";
import { EqualizerPanel } from "@/components/equalizer-panel";
import { useToast } from "@/hooks/use-toast";
import { useAudio } from "@/hooks/use-audio";
import { useVisualizerStore } from "@/hooks/use-visualizer";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { getYoutubeId, getYoutubeThumbnail } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { 
  DEFAULT_VISUALIZER_SETTINGS, 
  DEFAULT_PARTICLE_SETTINGS, 
  DEFAULT_BACKGROUND_SETTINGS,
  DEFAULT_EQUALIZER_SETTINGS,
  Track,
  BackgroundType,
} from "@shared/schema";

export function Customizer() {
  const [activeTab, setActiveTab] = useState("visualizer");
  const [visualizerSettings, setVisualizerSettings] = useState(DEFAULT_VISUALIZER_SETTINGS);
  const [particleSettings, setParticleSettings] = useState(DEFAULT_PARTICLE_SETTINGS);
  const [backgroundSettings, setBackgroundSettings] = useState(DEFAULT_BACKGROUND_SETTINGS);
  const [equalizerSettings, setEqualizerSettings] = useState(DEFAULT_EQUALIZER_SETTINGS);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { audioData } = useAudio();
  const setVisualizerStoreSettings = useVisualizerStore((state) => state.setSettings);
  
  // Sync settings with visualizer store
  useEffect(() => {
    setVisualizerStoreSettings(visualizerSettings);
  }, [visualizerSettings, setVisualizerStoreSettings]);
  
  // Save user preferences mutation
  const savePreferencesMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would save to the server
      // For now, we'll just store in local storage
      const preferences = {
        visualizerSettings,
        particleSettings,
        backgroundSettings,
        equalizerSettings,
      };
      
      localStorage.setItem('userPreferences', JSON.stringify(preferences));
      return preferences;
    },
    onSuccess: () => {
      toast({
        title: "Preferences saved",
        description: "Your customization settings have been saved.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to save preferences",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Load preferences from local storage
  useEffect(() => {
    const savedPreferences = localStorage.getItem('userPreferences');
    if (savedPreferences) {
      try {
        const preferences = JSON.parse(savedPreferences);
        if (preferences.visualizerSettings) setVisualizerSettings(preferences.visualizerSettings);
        if (preferences.particleSettings) setParticleSettings(preferences.particleSettings);
        if (preferences.backgroundSettings) setBackgroundSettings(preferences.backgroundSettings);
        if (preferences.equalizerSettings) setEqualizerSettings(preferences.equalizerSettings);
      } catch (error) {
        console.error("Failed to parse saved preferences:", error);
      }
    }
  }, []);
  
  // Handle YouTube import
  const importYoutubeMutation = useMutation({
    mutationFn: async (url: string) => {
      const videoId = getYoutubeId(url);
      if (!videoId) throw new Error("Invalid YouTube URL");
      
      // Extract video details from URL (in a real app, we'd fetch video details from YouTube API)
      const sourceUrl = url;
      const coverUrl = getYoutubeThumbnail(videoId);
      
      // Create a new track
      const newTrack = await apiRequest('POST', '/api/tracks', {
        title: "YouTube Import", // Would be actual title in real implementation
        artist: "YouTube", // Would be actual channel name in real implementation
        duration: 0, // Would be actual duration in real implementation
        source: "youtube",
        sourceUrl,
        coverUrl,
      });
      
      return newTrack.json();
    },
    onSuccess: (track) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      setCurrentTrack(track);
      toast({
        title: "YouTube video imported",
        description: "The video has been added and is now playing",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to import YouTube video",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Handle audio file upload
  const uploadFileMutation = useMutation({
    mutationFn: async ({ file, title, artist }: { file: File; title: string; artist: string }) => {
      const formData = new FormData();
      formData.append('audioFile', file);
      formData.append('title', title);
      formData.append('artist', artist);
      
      const response = await fetch('/api/tracks/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }
      
      return response.json();
    },
    onSuccess: (track) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      setCurrentTrack(track);
      toast({
        title: "Audio file uploaded",
        description: "The track has been added and is now playing",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to upload audio file",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Handle background image upload
  const uploadBackgroundMutation = useMutation({
    mutationFn: async (file: File) => {
      // In a real implementation, we would upload the image to a server
      // For now, we'll create a local object URL
      return URL.createObjectURL(file);
    },
    onSuccess: (imageUrl) => {
      setBackgroundSettings({
        ...backgroundSettings,
        type: 'image' as BackgroundType,
        imageUrl,
      });
      toast({
        title: "Background uploaded",
        description: "Your custom background has been applied",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to upload background",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  const handleYoutubeImport = (url: string) => {
    importYoutubeMutation.mutate(url);
  };
  
  const handleFileUpload = (file: File, title: string, artist: string) => {
    uploadFileMutation.mutate({ file, title, artist });
  };
  
  const handleBackgroundUpload = async (file: File) => {
    return uploadBackgroundMutation.mutateAsync(file);
  };
  
  const handleSavePreferences = () => {
    savePreferencesMutation.mutate();
  };
  
  return (
    <MainLayout>
      {/* Background with styling based on settings */}
      <div 
        className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none" 
        style={{
          backgroundImage: backgroundSettings.type === 'image' ? `url(${backgroundSettings.imageUrl})` : undefined,
          backgroundColor: backgroundSettings.type === 'color' ? backgroundSettings.color : undefined,
          background: backgroundSettings.type === 'gradient' ? backgroundSettings.color : undefined,
          opacity: backgroundSettings.opacity / 100,
          filter: `blur(${backgroundSettings.blur}px)`,
        }}
      />
      
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        {/* Welcome section */}
        <section className="mb-10 relative">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-6">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Customize Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">Anime Music</span> Experience
              </h1>
              <p className="text-white/70 mb-6">Create your perfect relaxing anime music environment with customizable visualizers, particles and backgrounds.</p>
              
              <div className="flex flex-wrap gap-4">
                <AudioSourceSelector 
                  onSelectYouTube={handleYoutubeImport}
                  onUploadFile={handleFileUpload}
                />
                
                <button 
                  className="bg-neon-purple/20 hover:bg-neon-purple/30 text-white px-5 py-3 rounded-lg flex items-center transition shadow-lg shadow-neon-purple/20"
                  onClick={handleSavePreferences}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                    <polyline points="7 3 7 8 15 8"></polyline>
                  </svg>
                  Save Settings
                </button>
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* Current track with visualizer */}
        <section className="mb-10">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center gap-6">
                <div className="flex-shrink-0">
                  <div className="w-32 h-32 md:w-40 md:h-40 rounded-lg overflow-hidden relative animate-pulse-slow">
                    {currentTrack ? (
                      <img 
                        src={currentTrack.coverUrl || (currentTrack.source === 'youtube' ? getYoutubeThumbnail(getYoutubeId(currentTrack.sourceUrl) || '') : '')}
                        alt="Now playing" 
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-dark-elevated to-dark-base flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white/20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10" />
                          <polygon points="10 8 16 12 10 16 10 8" />
                        </svg>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-br from-transparent to-dark-base/50"></div>
                  </div>
                </div>
                
                <div className="flex-grow">
                  <h2 className="text-2xl font-bold mb-1 text-white">
                    {currentTrack ? currentTrack.title : "No track selected"}
                  </h2>
                  <p className="text-white/70 mb-3">
                    {currentTrack ? currentTrack.artist || "Unknown Artist" : "Select a track to begin"}
                  </p>
                  
                  <div className="h-32 visualizer-container mb-4 bg-dark-elevated/50 rounded-lg overflow-hidden">
                    {audioData ? (
                      <Waveform 
                        audioData={audioData}
                        type={visualizerSettings.type}
                        barCount={visualizerSettings.barCount}
                        sensitivity={visualizerSettings.sensitivity}
                        colorStyle={visualizerSettings.colorStyle}
                        colorIntensity={visualizerSettings.colorIntensity}
                        glowEffect={visualizerSettings.glowEffect}
                        mirrorEffect={visualizerSettings.mirrorEffect}
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-white/50">Waiting for audio...</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* Customization Tabs */}
        <section className="mb-10">
          <div className="border-b border-white/10 mb-6">
            <div className="flex flex-wrap -mb-px">
              <button 
                className={`mr-2 py-2 px-4 ${activeTab === "visualizer" ? "text-neon-blue border-b-2 border-neon-blue" : "text-white/70 hover:text-white/90 border-b-2 border-transparent"}`}
                onClick={() => setActiveTab("visualizer")}
              >
                Visualizer
              </button>
              <button 
                className={`mr-2 py-2 px-4 ${activeTab === "particles" ? "text-neon-blue border-b-2 border-neon-blue" : "text-white/70 hover:text-white/90 border-b-2 border-transparent"}`}
                onClick={() => setActiveTab("particles")}
              >
                Particles
              </button>
              <button 
                className={`mr-2 py-2 px-4 ${activeTab === "background" ? "text-neon-blue border-b-2 border-neon-blue" : "text-white/70 hover:text-white/90 border-b-2 border-transparent"}`}
                onClick={() => setActiveTab("background")}
              >
                Background
              </button>
              <button 
                className={`mr-2 py-2 px-4 ${activeTab === "equalizer" ? "text-neon-blue border-b-2 border-neon-blue" : "text-white/70 hover:text-white/90 border-b-2 border-transparent"}`}
                onClick={() => setActiveTab("equalizer")}
              >
                Equalizer
              </button>
            </div>
          </div>
          
          {/* Settings content based on active tab */}
          <div>
            {activeTab === "visualizer" && (
              <VisualizerSettings 
                settings={visualizerSettings}
                onChange={setVisualizerSettings}
              />
            )}
            
            {activeTab === "particles" && (
              <ParticleSettings 
                settings={particleSettings}
                onChange={setParticleSettings}
              />
            )}
            
            {activeTab === "background" && (
              <BackgroundSettings 
                settings={backgroundSettings}
                onChange={setBackgroundSettings}
                onUploadBackground={handleBackgroundUpload}
              />
            )}
            
            {activeTab === "equalizer" && (
              <EqualizerPanel 
                settings={equalizerSettings}
                onChange={setEqualizerSettings}
                className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden"
              />
            )}
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

export default Customizer;
