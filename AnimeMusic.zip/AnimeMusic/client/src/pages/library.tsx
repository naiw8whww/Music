import { useState } from "react";
import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlaylistCard } from "@/components/playlist-card";
import { ParticleSystem } from "@/components/ui/particle-system";
import { useAudio } from "@/hooks/use-audio";
import { useParticleStore } from "@/hooks/use-particles";
import { useQuery } from "@tanstack/react-query";
import { Playlist, Track } from "@shared/schema";
import { Link } from "wouter";

export function Library() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("playlists");
  const { audioData } = useAudio();
  const particleSettings = useParticleStore((state) => state.settings);
  
  // Fetch playlists
  const { data: playlists = [], isLoading: isLoadingPlaylists } = useQuery({
    queryKey: ['/api/playlists'],
  });
  
  // Fetch tracks (search)
  const { data: tracks = [], isLoading: isLoadingTracks } = useQuery({
    queryKey: ['/api/tracks', searchQuery],
    queryFn: async ({ queryKey }) => {
      const [_, query] = queryKey;
      if (!query) return [];
      const response = await fetch(`/api/tracks?q=${encodeURIComponent(query)}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to search tracks');
      return response.json();
    },
    enabled: !!searchQuery,
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The search will be triggered by the searchQuery state change
  };
  
  const handlePlayPlaylist = (playlist: Playlist) => {
    // In a real implementation, this would start playing the playlist
    console.log("Playing playlist:", playlist);
  };
  
  return (
    <MainLayout>
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        {/* Header section */}
        <section className="mb-10">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-6">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">Music</span> Library
              </h1>
              <p className="text-white/70 mb-6">Browse and manage your playlists and favorite tracks</p>
              
              <form onSubmit={handleSearch} className="flex gap-2">
                <Input 
                  type="search"
                  placeholder="Search for tracks or artists..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-dark-elevated border-none text-white w-full max-w-md"
                />
                <Button type="submit" className="bg-neon-blue/20 hover:bg-neon-blue/30 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                </Button>
              </form>
            </CardContent>
          </Card>
        </section>
        
        {/* Tabs for Playlists/Tracks */}
        <section>
          <Tabs defaultValue="playlists" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-dark-elevated mb-6">
              <TabsTrigger value="playlists" className="data-[state=active]:bg-dark-surface data-[state=active]:text-neon-blue">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15V6H8V15M21 15H8M21 15V19H8V15M3 6V19" />
                  <path d="M3 15H8" />
                  <path d="M3 9H8" />
                </svg>
                Playlists
              </TabsTrigger>
              <TabsTrigger value="tracks" className="data-[state=active]:bg-dark-surface data-[state=active]:text-neon-pink">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="5.5" cy="17.5" r="2.5" />
                  <circle cx="18.5" cy="17.5" r="2.5" />
                  <path d="M5.5 15V8.5l13 1V17.5" />
                  <path d="M18.5 8.5v-7l-13 1v7" />
                </svg>
                Tracks
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="playlists">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-2xl font-bold text-white">Your Playlists</h2>
                <Link href="/create-playlist">
                  <Button className="bg-neon-pink/20 hover:bg-neon-pink/30 text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10" />
                      <line x1="12" y1="8" x2="12" y2="16" />
                      <line x1="8" y1="12" x2="16" y2="12" />
                    </svg>
                    Create New Playlist
                  </Button>
                </Link>
              </div>
              
              {isLoadingPlaylists ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Card key={i} className="bg-dark-surface/50 border-none h-60 animate-pulse">
                      <div className="h-40 bg-dark-elevated/50"></div>
                      <CardContent className="p-4">
                        <div className="h-4 bg-dark-elevated/50 rounded w-2/3 mb-2"></div>
                        <div className="h-3 bg-dark-elevated/50 rounded w-1/2"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : playlists.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {playlists.map((playlist: Playlist) => (
                    <PlaylistCard 
                      key={playlist.id} 
                      playlist={playlist} 
                      onPlay={handlePlayPlaylist}
                    />
                  ))}
                  <Link href="/create-playlist">
                    <a className="bg-dark-surface/40 backdrop-blur-md rounded-lg overflow-hidden border border-dashed border-white/30 flex flex-col items-center justify-center h-60 hover:bg-dark-surface/60 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/60 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" />
                        <line x1="12" y1="8" x2="12" y2="16" />
                        <line x1="8" y1="12" x2="16" y2="12" />
                      </svg>
                      <span className="text-white/60">Create New Playlist</span>
                    </a>
                  </Link>
                </div>
              ) : (
                <div className="text-center py-12">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-white/20 mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15V6H8V15M21 15H8M21 15V19H8V15M3 6V19" />
                    <path d="M3 15H8" />
                    <path d="M3 9H8" />
                  </svg>
                  <h3 className="text-xl font-semibold mb-2 text-white/90">No playlists yet</h3>
                  <p className="text-white/60 mb-6">Create your first playlist to organize your favorite tracks</p>
                  <Link href="/create-playlist">
                    <Button className="bg-neon-pink hover:bg-neon-pink/90">
                      Create New Playlist
                    </Button>
                  </Link>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="tracks">
              <div className="mb-5">
                <h2 className="text-2xl font-bold text-white">Search Results</h2>
              </div>
              
              {searchQuery ? (
                isLoadingTracks ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <Card key={i} className="bg-dark-surface/50 border-none animate-pulse">
                        <CardContent className="p-4 flex items-center gap-4">
                          <div className="w-12 h-12 bg-dark-elevated/50 rounded"></div>
                          <div className="flex-grow">
                            <div className="h-4 bg-dark-elevated/50 rounded w-1/3 mb-2"></div>
                            <div className="h-3 bg-dark-elevated/50 rounded w-1/4"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : tracks.length > 0 ? (
                  <div className="space-y-2">
                    {tracks.map((track: Track) => (
                      <Card key={track.id} className="bg-dark-surface/80 backdrop-blur-md border-none hover:bg-dark-surface/90 transition-colors">
                        <CardContent className="p-4 flex items-center gap-4">
                          <div className="w-12 h-12 rounded overflow-hidden bg-dark-elevated flex-shrink-0">
                            {track.coverUrl && (
                              <img 
                                src={track.coverUrl} 
                                alt={track.title} 
                                className="w-full h-full object-cover"
                              />
                            )}
                          </div>
                          <div className="flex-grow">
                            <h3 className="font-medium text-white">{track.title}</h3>
                            <p className="text-white/60 text-sm">{track.artist || "Unknown Artist"}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="text-white/70 hover:text-white hover:bg-white/10">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polygon points="5 3 19 12 5 21 5 3"></polygon>
                            </svg>
                          </Button>
                          <Button variant="ghost" size="icon" className="text-white/70 hover:text-white hover:bg-white/10">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M3 6h18"></path>
                              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                              <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-white/20 mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="11" cy="11" r="8" />
                      <line x1="21" y1="21" x2="16.65" y2="16.65" />
                      <line x1="11" y1="8" x2="11" y2="14" />
                      <line x1="8" y1="11" x2="14" y2="11" />
                    </svg>
                    <h3 className="text-xl font-semibold mb-2 text-white/90">No tracks found</h3>
                    <p className="text-white/60">Try a different search term</p>
                  </div>
                )
              ) : (
                <div className="text-center py-12">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-white/20 mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                  <h3 className="text-xl font-semibold mb-2 text-white/90">Search for tracks</h3>
                  <p className="text-white/60">Enter a search term to find tracks</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </section>
      </div>
    </MainLayout>
  );
}

export default Library;
