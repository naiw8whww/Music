import { useState, useEffect } from "react";
import { Link } from "wouter";
import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlaylistCard } from "@/components/playlist-card";
import { ParticleSystem } from "@/components/ui/particle-system";
import { AudioSourceSelector } from "@/components/ui/audio-source-selector";
import { BackgroundSelector } from "@/components/ui/background-selector";
import { BackgroundType, Playlist, Track, DEFAULT_BACKGROUND_SETTINGS, DEFAULT_PARTICLE_SETTINGS } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getYoutubeId, getYoutubeThumbnail } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useAudio } from "@/hooks/use-audio";
import { useVisualizerStore } from "@/hooks/use-visualizer";
import { useParticleStore } from "@/hooks/use-particles";

export function Home() {
  const [backgroundSettings, setBackgroundSettings] = useState(DEFAULT_BACKGROUND_SETTINGS);
  const [particleSettings, setParticleSettings] = useState(DEFAULT_PARTICLE_SETTINGS);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { audioData } = useAudio();
  const setVisualizerSettings = useVisualizerStore((state) => state.setSettings);
  const setParticleStoreSettings = useParticleStore((state) => state.setSettings);
  
  // Sync settings with global stores
  useEffect(() => {
    setParticleStoreSettings(particleSettings);
  }, [particleSettings, setParticleStoreSettings]);
  
  // Fetch featured playlists
  const { data: playlists = [] } = useQuery({
    queryKey: ['/api/playlists'],
  });
  
  // Handle YouTube import
  const importYoutubeMutation = useMutation({
    mutationFn: async (url: string) => {
      const videoId = getYoutubeId(url);
      if (!videoId) throw new Error("Invalid YouTube URL");
      
      // Extract video details from URL (in a real app, we'd fetch video details from YouTube API)
      const sourceUrl = url;
      const coverUrl = getYoutubeThumbnail(videoId);
      
      // Create a new track
      const newTrack = await apiRequest('POST', '/api/tracks', {
        title: "YouTube Import", // Would be actual title in real implementation
        artist: "YouTube", // Would be actual channel name in real implementation
        duration: 0, // Would be actual duration in real implementation
        source: "youtube",
        sourceUrl,
        coverUrl,
      });
      
      return newTrack.json();
    },
    onSuccess: (track) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      toast({
        title: "YouTube video imported",
        description: "The video has been added to your library",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to import YouTube video",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Handle audio file upload
  const uploadFileMutation = useMutation({
    mutationFn: async ({ file, title, artist }: { file: File; title: string; artist: string }) => {
      const formData = new FormData();
      formData.append('audioFile', file);
      formData.append('title', title);
      formData.append('artist', artist);
      
      const response = await fetch('/api/tracks/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }
      
      return response.json();
    },
    onSuccess: (track) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      toast({
        title: "Audio file uploaded",
        description: "The track has been added to your library",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to upload audio file",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  // Handle background image upload
  const uploadBackgroundMutation = useMutation({
    mutationFn: async (file: File) => {
      // In a real implementation, we would upload the image to a server
      // For now, we'll create a local object URL
      return URL.createObjectURL(file);
    },
    onSuccess: (imageUrl) => {
      setBackgroundSettings({
        ...backgroundSettings,
        type: 'image' as BackgroundType,
        imageUrl,
      });
      toast({
        title: "Background uploaded",
        description: "Your custom background has been applied",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to upload background",
        description: error.toString(),
        variant: "destructive",
      });
    }
  });
  
  const handleYoutubeImport = (url: string) => {
    importYoutubeMutation.mutate(url);
  };
  
  const handleFileUpload = (file: File, title: string, artist: string) => {
    uploadFileMutation.mutate({ file, title, artist });
  };
  
  const handleBackgroundUpload = async (file: File) => {
    return uploadBackgroundMutation.mutateAsync(file);
  };
  
  const handlePlayPlaylist = (playlist: Playlist) => {
    // In a real implementation, this would start playing the playlist
    console.log("Playing playlist:", playlist);
  };
  
  return (
    <MainLayout>
      {/* Background with anime character */}
      <div 
        className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none" 
        style={{
          backgroundImage: backgroundSettings.type === 'image' ? `url(${backgroundSettings.imageUrl})` : undefined,
          backgroundColor: backgroundSettings.type === 'color' ? backgroundSettings.color : undefined,
          background: backgroundSettings.type === 'gradient' ? backgroundSettings.color : undefined,
          opacity: backgroundSettings.opacity / 100,
          filter: `blur(${backgroundSettings.blur}px)`,
        }}
      />
      
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        {/* Welcome section */}
        <section className="mb-10 relative">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-6">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Customize Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">Anime Music</span> Experience
              </h1>
              <p className="text-white/70 mb-6">Create your perfect relaxing anime music environment with customizable visualizers, particles and backgrounds.</p>
              
              <div className="flex flex-wrap gap-4">
                <AudioSourceSelector 
                  onSelectYouTube={handleYoutubeImport}
                  onUploadFile={handleFileUpload}
                />
                
                <BackgroundSelector 
                  onSelectBackground={(background) => setBackgroundSettings({
                    ...backgroundSettings,
                    type: 'image' as BackgroundType,
                    imageUrl: background,
                  })}
                  onUploadBackground={handleBackgroundUpload}
                  onOpacityChange={(opacity) => setBackgroundSettings({
                    ...backgroundSettings,
                    opacity,
                  })}
                  onBlurChange={(blur) => setBackgroundSettings({
                    ...backgroundSettings,
                    blur,
                  })}
                  opacity={backgroundSettings.opacity}
                  blur={backgroundSettings.blur}
                  selectedBackground={backgroundSettings.type === 'image' ? backgroundSettings.imageUrl : undefined}
                />
                
                <Link href="/customizer">
                  <Button className="bg-neon-purple/20 hover:bg-neon-purple/30 text-white shadow-lg shadow-neon-purple/20">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="4" y1="21" x2="4" y2="14" />
                      <line x1="4" y1="10" x2="4" y2="3" />
                      <line x1="12" y1="21" x2="12" y2="12" />
                      <line x1="12" y1="8" x2="12" y2="3" />
                      <line x1="20" y1="21" x2="20" y2="16" />
                      <line x1="20" y1="12" x2="20" y2="3" />
                      <line x1="1" y1="14" x2="7" y2="14" />
                      <line x1="9" y1="8" x2="15" y2="8" />
                      <line x1="17" y1="16" x2="23" y2="16" />
                    </svg>
                    Customize Experience
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* Playlists section */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-2xl font-bold text-white">Your Playlists</h2>
            <Link href="/library">
              <a className="text-neon-blue hover:text-neon-blue/80 text-sm font-medium">
                View All
              </a>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {playlists.slice(0, 3).map((playlist) => (
              <PlaylistCard 
                key={playlist.id} 
                playlist={playlist} 
                onPlay={handlePlayPlaylist}
              />
            ))}
            
            <Link href="/create-playlist">
              <a className="bg-dark-surface/40 backdrop-blur-md rounded-lg overflow-hidden border border-dashed border-white/30 flex flex-col items-center justify-center h-60 hover:bg-dark-surface/60 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white/60 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="16" />
                  <line x1="8" y1="12" x2="16" y2="12" />
                </svg>
                <span className="text-white/60">Create New Playlist</span>
              </a>
            </Link>
          </div>
        </section>
        
        {/* Features section */}
        <section className="mb-10">
          <h2 className="text-2xl font-bold mb-6 text-white">Features</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
              <CardContent className="p-5 relative">
                <div className="h-12 w-12 rounded-full bg-neon-blue/20 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-neon-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 22h14a2 2 0 0 0 2-2V7.5L14.5 2H6a2 2 0 0 0-2 2v4" />
                    <polyline points="14 2 14 8 20 8" />
                    <path d="M2 15h10" />
                    <path d="M9 18l3-3-3-3" />
                  </svg>
                </div>
                <h3 className="font-bold text-lg mb-2 text-white">Customizable Visualizers</h3>
                <p className="text-white/70 text-sm">
                  Create stunning visual experiences with our highly customizable audio visualizers. Choose from bars, waves, or circular patterns with adjustable colors and effects.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-pink to-neon-orange" />
              <CardContent className="p-5 relative">
                <div className="h-12 w-12 rounded-full bg-neon-pink/20 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-neon-pink" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
                    <path d="M20.859 10.995a8.965 8.965 0 0 0-9.864-9.864" />
                    <circle cx="12" cy="12" r="0" />
                  </svg>
                </div>
                <h3 className="font-bold text-lg mb-2 text-white">Interactive Particles</h3>
                <p className="text-white/70 text-sm">
                  Enhance your music with interactive particle effects that respond to the beat. Choose from fireflies, snow, or fully reactive particles that dance to your music.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-orange to-neon-blue" />
              <CardContent className="p-5 relative">
                <div className="h-12 w-12 rounded-full bg-neon-orange/20 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-neon-orange" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                  </svg>
                </div>
                <h3 className="font-bold text-lg mb-2 text-white">Multiple Music Sources</h3>
                <p className="text-white/70 text-sm">
                  Play music from YouTube, upload your own tracks, or create playlists from different sources. Perfect for anime soundtracks and lofi beats.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* Anime character section */}
        <section className="mb-10">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-0 relative">
              <div className="grid md:grid-cols-2 gap-0">
                <div className="p-8 flex flex-col justify-center">
                  <h2 className="text-2xl font-bold mb-4 text-white">Relax with Anime-Inspired Visuals</h2>
                  <p className="text-white/70 mb-6">
                    Immerse yourself in a world of anime-inspired visuals while listening to your favorite music. Our app combines beautiful anime aesthetics with relaxing music to create the perfect atmosphere.
                  </p>
                  <Link href="/customizer">
                    <Button className="w-fit bg-gradient-to-r from-neon-blue to-neon-pink hover:opacity-90 transition shadow-lg">
                      Start Customizing
                    </Button>
                  </Link>
                </div>
                <div className="h-64 md:h-auto overflow-hidden relative">
                  <img 
                    src="https://images.unsplash.com/photo-1546353239-e7e7913d5490?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
                    alt="Anime character relaxing with music" 
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-dark-surface/80 to-transparent md:bg-gradient-to-l" />
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </MainLayout>
  );
}

export default Home;
