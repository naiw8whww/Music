import { MainLayout } from "@/components/layouts/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { ParticleSystem } from "@/components/ui/particle-system";
import { useAudio } from "@/hooks/use-audio";
import { useParticleStore } from "@/hooks/use-particles";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function About() {
  const { audioData } = useAudio();
  const particleSettings = useParticleStore((state) => state.settings);
  
  return (
    <MainLayout>
      {/* Particle effects */}
      {particleSettings.enabled && (
        <ParticleSystem 
          type={particleSettings.type}
          density={particleSettings.density}
          size={particleSettings.size}
          speed={particleSettings.speed}
          audioData={audioData || undefined}
        />
      )}
      
      <div className="p-4 md:p-8">
        {/* Header section */}
        <section className="mb-10">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-pink" />
            <CardContent className="p-6">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                About <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">AnimeBeats</span>
              </h1>
              <p className="text-white/70 mb-0">An immersive anime-themed music experience with customizable visualizers and effects</p>
            </CardContent>
          </Card>
        </section>
        
        {/* About content */}
        <section className="mb-10">
          <Card className="bg-dark-surface/80 backdrop-blur-md border-none shadow-lg relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-gradient-to-br from-neon-blue to-neon-orange" />
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h2 className="text-2xl font-bold mb-4 text-white">Our Mission</h2>
                  <p className="text-white/70 mb-4">
                    AnimeBeats was created to combine the relaxing world of anime aesthetics with immersive music visualization. 
                    Our goal is to provide a customizable experience that helps you relax, focus, or simply enjoy your favorite music
                    in a whole new way.
                  </p>
                  <p className="text-white/70 mb-4">
                    We believe that music isn't just about listening—it's about experiencing. That's why we've built a platform
                    that engages multiple senses, with reactive visualizers, particle effects, and anime-inspired design.
                  </p>
                  
                  <h2 className="text-2xl font-bold mb-4 mt-8 text-white">Features</h2>
                  <ul className="space-y-3 text-white/70">
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Customizable audio visualizers with multiple styles</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Interactive particle effects that react to your music</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Support for multiple music sources including YouTube and local files</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Customizable backgrounds and themes</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Advanced audio equalizer for the perfect sound</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neon-blue mr-2 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                      <span>Create and manage playlists for your favorite tracks</span>
                    </li>
                  </ul>
                </div>
                
                <div>
                  <div className="rounded-lg overflow-hidden mb-6">
                    <img 
                      src="https://images.unsplash.com/photo-1546353239-e7e7913d5490?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
                      alt="Anime character relaxing"
                      className="w-full h-64 object-cover"
                    />
                  </div>
                  
                  <h2 className="text-2xl font-bold mb-4 text-white">How to Use</h2>
                  <ol className="space-y-3 text-white/70 list-decimal ml-5">
                    <li>Upload music from your device or import from YouTube</li>
                    <li>Choose your preferred visualizer style and customize its appearance</li>
                    <li>Adjust particle effects to match the mood of your music</li>
                    <li>Select a background or upload your own</li>
                    <li>Fine-tune your sound with the equalizer</li>
                    <li>Create playlists to organize your music</li>
                    <li>Sit back, relax, and enjoy the experience!</li>
                  </ol>
                  
                  <div className="mt-8 space-y-4">
                    <h2 className="text-2xl font-bold mb-4 text-white">Get Started</h2>
                    <div className="flex flex-wrap gap-4">
                      <Link href="/customizer">
                        <Button className="bg-gradient-to-r from-neon-blue to-neon-pink hover:opacity-90 transition shadow-lg">
                          Try the Customizer
                        </Button>
                      </Link>
                      <Link href="/library">
                        <Button className="bg-neon-purple/20 hover:bg-neon-purple/30 text-white shadow-lg shadow-neon-purple/20">
                          Browse Music Library
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </MainLayout>
  );
}

export default About;
