import { create } from 'zustand';
import { DEFAULT_PARTICLE_SETTINGS } from '@shared/schema';

interface ParticleState {
  settings: typeof DEFAULT_PARTICLE_SETTINGS;
  setSettings: (settings: typeof DEFAULT_PARTICLE_SETTINGS) => void;
  isVisible: boolean;
  setVisibility: (visible: boolean) => void;
}

export const useParticleStore = create<ParticleState>((set) => ({
  settings: DEFAULT_PARTICLE_SETTINGS,
  isVisible: true,
  setSettings: (settings) => set({ settings }),
  setVisibility: (visible) => set({ isVisible: visible }),
}));

// Helper hook for components
export function useParticles() {
  const { 
    settings, 
    isVisible, 
    setSettings, 
    setVisibility 
  } = useParticleStore();
  
  const toggleVisibility = () => {
    setVisibility(!isVisible);
  };
  
  const updateParticleType = (type: typeof DEFAULT_PARTICLE_SETTINGS.type) => {
    setSettings({
      ...settings,
      type,
    });
  };
  
  const updateParticleDensity = (density: number) => {
    setSettings({
      ...settings,
      density,
    });
  };
  
  const updateParticleSize = (size: number) => {
    setSettings({
      ...settings,
      size,
    });
  };
  
  const updateParticleSpeed = (speed: number) => {
    setSettings({
      ...settings,
      speed,
    });
  };
  
  const enableParticles = (enabled: boolean) => {
    setSettings({
      ...settings,
      enabled,
    });
  };

  return {
    settings,
    isVisible,
    setSettings,
    toggleVisibility,
    updateParticleType,
    updateParticleDensity,
    updateParticleSize,
    updateParticleSpeed,
    enableParticles,
  };
}

export default useParticles;
