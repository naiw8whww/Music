import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Customizer from "@/pages/customizer";
import Library from "@/pages/library";
import About from "@/pages/about";
import PlaylistDetail from "@/pages/playlist-detail";
import CreatePlaylist from "@/pages/create-playlist";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/customizer" component={Customizer} />
      <Route path="/library" component={Library} />
      <Route path="/about" component={About} />
      <Route path="/playlist/:id" component={PlaylistDetail} />
      <Route path="/create-playlist" component={CreatePlaylist} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
