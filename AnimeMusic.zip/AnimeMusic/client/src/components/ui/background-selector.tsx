import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { PRESET_BACKGROUNDS } from "@shared/schema";

interface BackgroundSelectorProps {
  onSelectBackground: (background: string) => void;
  onUploadBackground: (file: File) => void;
  onOpacityChange: (opacity: number) => void;
  onBlurChange: (blur: number) => void;
  opacity?: number;
  blur?: number;
  selectedBackground?: string;
}

export function BackgroundSelector({
  onSelectBackground,
  onUploadBackground,
  onOpacityChange,
  onBlurChange,
  opacity = 20,
  blur = 0,
  selectedBackground
}: BackgroundSelectorProps) {
  const [open, setOpen] = useState(false);
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadBackground(e.target.files[0]);
      setOpen(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-neon-orange/20 hover:bg-neon-orange/30 text-white border-none shadow-lg shadow-neon-orange/20">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
          Change Background
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[725px] bg-dark-surface/80 backdrop-blur-md border-none text-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Background Gallery</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {PRESET_BACKGROUNDS.map((bg) => (
              <div 
                key={bg.id}
                className={`relative rounded-lg overflow-hidden h-32 cursor-pointer group hover:ring-2 ${selectedBackground === bg.url ? 'ring-2 ring-neon-pink' : ''}`}
                onClick={() => {
                  onSelectBackground(bg.url);
                  setOpen(false);
                }}
              >
                <img 
                  src={bg.url} 
                  alt={bg.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-base to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                  <span className="text-white text-sm font-medium">{bg.name}</span>
                </div>
              </div>
            ))}
            
            <div className="rounded-lg overflow-hidden h-32 bg-dark-elevated border border-dashed border-white/30 flex flex-col items-center justify-center">
              <Input 
                type="file" 
                id="bg-upload" 
                className="hidden" 
                accept="image/*" 
                onChange={handleFileUpload}
              />
              <label 
                htmlFor="bg-upload" 
                className="cursor-pointer flex flex-col items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white/60 mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 5v14M5 12h14" />
                </svg>
                <span className="text-white/60 text-sm">Upload Custom</span>
              </label>
            </div>
          </div>
          
          <Card className="bg-dark-elevated border-none">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="text-sm text-white/70">Background Opacity</Label>
                  <span className="text-sm text-white/70">{opacity}%</span>
                </div>
                <Slider
                  defaultValue={[opacity]}
                  max={100}
                  step={1}
                  onValueChange={(value) => onOpacityChange(value[0])}
                  className="w-full"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="text-sm text-white/70">Blur Effect</Label>
                  <span className="text-sm text-white/70">{blur}px</span>
                </div>
                <Slider
                  defaultValue={[blur]}
                  max={20}
                  step={1}
                  onValueChange={(value) => onBlurChange(value[0])}
                  className="w-full"
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default BackgroundSelector;
