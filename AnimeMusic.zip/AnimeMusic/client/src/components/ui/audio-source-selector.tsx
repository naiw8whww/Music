import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { getYoutubeId } from "@/lib/utils";

interface AudioSourceSelectorProps {
  onSelectYouTube: (url: string) => void;
  onUploadFile: (file: File, title: string, artist: string) => void;
}

export function AudioSourceSelector({
  onSelectYouTube,
  onUploadFile,
}: AudioSourceSelectorProps) {
  const [open, setOpen] = useState(false);
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadArtist, setUploadArtist] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleYoutubeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate YouTube URL
    const videoId = getYoutubeId(youtubeUrl);
    if (!videoId) {
      toast({
        title: "Invalid YouTube URL",
        description: "Please enter a valid YouTube video URL",
        variant: "destructive",
      });
      return;
    }
    
    onSelectYouTube(youtubeUrl);
    setYoutubeUrl("");
    setOpen(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Try to extract title from filename
      if (!uploadTitle) {
        const filename = selectedFile.name.replace(/\.[^/.]+$/, "");
        setUploadTitle(filename);
      }
    }
  };

  const handleFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select an audio file to upload",
        variant: "destructive",
      });
      return;
    }
    
    if (!uploadTitle) {
      toast({
        title: "Title required",
        description: "Please enter a title for your track",
        variant: "destructive",
      });
      return;
    }
    
    onUploadFile(file, uploadTitle, uploadArtist);
    setFile(null);
    setUploadTitle("");
    setUploadArtist("");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          className="bg-neon-blue/20 hover:bg-neon-blue/30 text-white shadow-lg shadow-neon-blue/20 flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5" />
          </svg>
          Add Music
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-dark-surface/80 backdrop-blur-md border-none text-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Add Music</DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="youtube">
          <TabsList className="grid grid-cols-2 bg-dark-elevated">
            <TabsTrigger value="youtube" className="data-[state=active]:bg-dark-surface data-[state=active]:text-neon-blue">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
              </svg>
              YouTube
            </TabsTrigger>
            <TabsTrigger value="upload" className="data-[state=active]:bg-dark-surface data-[state=active]:text-neon-pink">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
              Upload File
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="youtube" className="pt-4">
            <form onSubmit={handleYoutubeSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="youtube-url">YouTube URL</Label>
                <Input
                  id="youtube-url"
                  placeholder="https://www.youtube.com/watch?v=..."
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  className="bg-dark-elevated border-none text-white"
                />
              </div>
              
              <Button type="submit" className="w-full bg-neon-pink hover:bg-neon-pink/90">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
                Play from YouTube
              </Button>
            </form>
          </TabsContent>
          
          <TabsContent value="upload" className="pt-4">
            <form onSubmit={handleFileSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="file-upload">Audio File</Label>
                <Input
                  id="file-upload"
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="bg-dark-elevated border-none text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="track-title">Title</Label>
                <Input
                  id="track-title"
                  placeholder="Track title"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="bg-dark-elevated border-none text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="track-artist">Artist (optional)</Label>
                <Input
                  id="track-artist"
                  placeholder="Artist name"
                  value={uploadArtist}
                  onChange={(e) => setUploadArtist(e.target.value)}
                  className="bg-dark-elevated border-none text-white"
                />
              </div>
              
              <Button type="submit" className="w-full bg-neon-blue hover:bg-neon-blue/90">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                  <polyline points="17 21 17 13 7 13 7 21" />
                  <polyline points="7 3 7 8 15 8" />
                </svg>
                Upload File
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default AudioSourceSelector;
