import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { DEFAULT_EQUALIZER_SETTINGS } from "@shared/schema";

interface EqualizerProps {
  bands: Array<{ frequency: string; gain: number }>;
  onBandChange: (index: number, gain: number) => void;
  onPresetSelect: (preset: string) => void;
  onResetBands: () => void;
  onSavePreset: () => void;
  className?: string;
}

export function Equalizer({
  bands = DEFAULT_EQUALIZER_SETTINGS.bands,
  onBandChange,
  onPresetSelect,
  onResetBands,
  onSavePreset,
  className
}: EqualizerProps) {
  const [isShowingFrequencies, setIsShowingFrequencies] = useState(true);
  
  const handleSliderChange = (index: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(event.target.value);
    onBandChange(index, value);
  };
  
  return (
    <div className={cn("space-y-4", className)}>
      <div className="flex items-end justify-center gap-3 h-32 mb-4">
        {bands.map((band, index) => (
          <div className="text-center" key={band.frequency}>
            <input
              type="range"
              min="0"
              max="100"
              value={band.gain}
              onChange={(e) => handleSliderChange(index, e)}
              className="h-32 w-8 appearance-none bg-gradient-to-t from-neon-blue to-neon-pink rounded-full outline-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-8 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-[0_0_5px_rgba(255,0,255,0.8)] [&::-webkit-slider-thumb]:cursor-pointer [&::-moz-range-thumb]:h-3 [&::-moz-range-thumb]:w-8 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-white [&::-moz-range-thumb]:border-none [&::-moz-range-thumb]:shadow-[0_0_5px_rgba(255,0,255,0.8)] [&::-moz-range-thumb]:cursor-pointer [&::-ms-thumb]:h-3 [&::-ms-thumb]:w-8 [&::-ms-thumb]:rounded-full [&::-ms-thumb]:bg-white [&::-ms-thumb]:shadow-[0_0_5px_rgba(255,0,255,0.8)] [&::-ms-thumb]:cursor-pointer"
              style={{ transform: 'rotate(180deg)' }}
            />
            <div className="text-xs text-white/60 mt-2">{band.frequency}</div>
          </div>
        ))}
      </div>
      
      <div className="flex justify-center gap-3 flex-wrap">
        <Button 
          variant="outline" 
          className="bg-neon-blue/20 hover:bg-neon-blue/30 text-white border-none"
          onClick={onResetBands}
        >
          Reset
        </Button>
        <Button 
          variant="outline" 
          className="bg-dark-elevated hover:bg-dark-elevated/80 text-white border-none"
          onClick={() => onPresetSelect('bassBoost')}
        >
          Bass Boost
        </Button>
        <Button 
          variant="outline"
          className="bg-dark-elevated hover:bg-dark-elevated/80 text-white border-none"
          onClick={() => onPresetSelect('vocalBoost')}
        >
          Vocal Boost
        </Button>
        <Button 
          variant="outline"
          className="bg-dark-elevated hover:bg-dark-elevated/80 text-white border-none"
          onClick={() => onPresetSelect('trebleBoost')}
        >
          Treble Boost
        </Button>
        <Button 
          variant="outline"
          className="bg-dark-elevated hover:bg-dark-elevated/80 text-white border-none"
          onClick={onSavePreset}
        >
          Save Preset
        </Button>
      </div>
    </div>
  );
}

export default Equalizer;
