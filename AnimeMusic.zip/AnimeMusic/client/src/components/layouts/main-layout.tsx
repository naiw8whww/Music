import { useState } from "react";
import { Link, useLocation } from "wouter";
import { MusicPlayer } from "@/components/music-player";
import { cn } from "@/lib/utils";
import { Track } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

export function MainLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  
  // Fetch playlists for sidebar
  const { data: playlists = [] } = useQuery({
    queryKey: ['/api/playlists'],
  });

  return (
    <div className="flex flex-col h-screen overflow-hidden text-white">
      {/* Header */}
      <header className="bg-dark-surface shadow-md z-30 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <a className="font-['Exo_2'] text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">
              AnimeBeats<span className="text-neon-orange">.</span>
            </a>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/">
            <a className="text-white/90 hover:text-neon-blue transition">Home</a>
          </Link>
          <Link href="/customizer">
            <a className={cn("text-white/90 hover:text-neon-blue transition", location === "/customizer" && "text-neon-blue")}>Customizer</a>
          </Link>
          <Link href="/library">
            <a className={cn("text-white/90 hover:text-neon-blue transition", location === "/library" && "text-neon-blue")}>Library</a>
          </Link>
          <Link href="/about">
            <a className={cn("text-white/90 hover:text-neon-blue transition", location === "/about" && "text-neon-blue")}>About</a>
          </Link>
          
          <button className="px-4 py-2 bg-gradient-to-r from-neon-blue to-neon-pink rounded-full font-medium hover:opacity-90 transition shadow-lg">
            Sign In
          </button>
        </div>
        
        <button 
          className="md:hidden text-2xl text-white/80"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {isMobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </header>
      
      {/* Mobile Menu (overlay) */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-dark-base/95 p-4">
          <div className="flex flex-col space-y-4 pt-16">
            <Link href="/">
              <a className="text-lg py-2 px-4 rounded-lg hover:bg-white/5" onClick={() => setIsMobileMenuOpen(false)}>Home</a>
            </Link>
            <Link href="/customizer">
              <a className="text-lg py-2 px-4 rounded-lg hover:bg-white/5" onClick={() => setIsMobileMenuOpen(false)}>Customizer</a>
            </Link>
            <Link href="/library">
              <a className="text-lg py-2 px-4 rounded-lg hover:bg-white/5" onClick={() => setIsMobileMenuOpen(false)}>Library</a>
            </Link>
            <Link href="/about">
              <a className="text-lg py-2 px-4 rounded-lg hover:bg-white/5" onClick={() => setIsMobileMenuOpen(false)}>About</a>
            </Link>
            
            <div className="pt-4 border-t border-white/10">
              <button className="w-full py-3 bg-gradient-to-r from-neon-blue to-neon-pink rounded-lg font-medium">
                Sign In
              </button>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex flex-grow overflow-hidden">
        {/* Sidebar (desktop only) */}
        <aside className="w-64 bg-dark-surface hidden md:block overflow-y-auto shadow-lg flex-shrink-0">
          <div className="p-4">
            <nav className="space-y-6">
              <div>
                <h3 className="text-xs uppercase text-white/50 font-semibold tracking-wider mb-3">Browse</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                          <polyline points="9 22 9 12 15 12 15 22" />
                        </svg>
                        <span>Home</span>
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/trending">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/trending" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                          <polyline points="17 6 23 6 23 12" />
                        </svg>
                        <span>Trending</span>
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/discover">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/discover" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10" />
                          <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
                        </svg>
                        <span>Discover</span>
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/customizer">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/customizer" && "bg-white/5 text-neon-pink")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className={cn("h-5 w-5 mr-3", location === "/customizer" && "text-neon-pink")} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="4" y1="21" x2="4" y2="14" />
                          <line x1="4" y1="10" x2="4" y2="3" />
                          <line x1="12" y1="21" x2="12" y2="12" />
                          <line x1="12" y1="8" x2="12" y2="3" />
                          <line x1="20" y1="21" x2="20" y2="16" />
                          <line x1="20" y1="12" x2="20" y2="3" />
                          <line x1="1" y1="14" x2="7" y2="14" />
                          <line x1="9" y1="8" x2="15" y2="8" />
                          <line x1="17" y1="16" x2="23" y2="16" />
                        </svg>
                        <span>Customizer</span>
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xs uppercase text-white/50 font-semibold tracking-wider mb-3">Your Library</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/favorites">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/favorites" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                        </svg>
                        <span>Favorites</span>
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/recent">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/recent" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10" />
                          <polyline points="12 6 12 12 16 14" />
                        </svg>
                        <span>Recently Played</span>
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/uploads">
                      <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === "/uploads" && "bg-white/5")}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                          <polyline points="17 8 12 3 7 8" />
                          <line x1="12" y1="3" x2="12" y2="15" />
                        </svg>
                        <span>My Uploads</span>
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xs uppercase text-white/50 font-semibold tracking-wider mb-3">Playlists</h3>
                <ul className="space-y-2">
                  {playlists.length > 0 ? (
                    playlists.map((playlist) => (
                      <li key={playlist.id}>
                        <Link href={`/playlist/${playlist.id}`}>
                          <a className={cn("flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5", location === `/playlist/${playlist.id}` && "bg-white/5")}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M9 18V5l12-2v13" />
                              <circle cx="6" cy="18" r="3" />
                              <circle cx="18" cy="16" r="3" />
                            </svg>
                            <span className="truncate">{playlist.name}</span>
                          </a>
                        </Link>
                      </li>
                    ))
                  ) : (
                    <li className="text-white/50 text-sm py-2 px-3">No playlists yet</li>
                  )}
                  <li>
                    <Link href="/create-playlist">
                      <a className="flex items-center text-white/80 hover:text-neon-blue py-2 px-3 rounded-lg hover:bg-white/5">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10" />
                          <line x1="12" y1="8" x2="12" y2="16" />
                          <line x1="8" y1="12" x2="16" y2="12" />
                        </svg>
                        <span>Create Playlist</span>
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
            </nav>
          </div>
        </aside>
        
        {/* Main content */}
        <main className="flex-grow overflow-y-auto bg-dark-base relative">
          {children}
        </main>
      </div>
      
      {/* Music player footer */}
      <MusicPlayer currentTrack={currentTrack} onChange={setCurrentTrack} />
    </div>
  );
}

export default MainLayout;
