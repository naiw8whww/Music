import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { DEFAULT_EQUALIZER_SETTINGS } from "@shared/schema";
import { Equalizer } from "@/components/ui/equalizer";

interface EqualizerPanelProps {
  settings: typeof DEFAULT_EQUALIZER_SETTINGS;
  onChange: (settings: typeof DEFAULT_EQUALIZER_SETTINGS) => void;
  className?: string;
}

export function EqualizerPanel({
  settings,
  onChange,
  className
}: EqualizerPanelProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  
  // Sync with props
  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);
  
  const handleBandChange = (index: number, gain: number) => {
    const newBands = [...localSettings.bands];
    newBands[index] = { ...newBands[index], gain };
    
    const newSettings = {
      ...localSettings,
      bands: newBands
    };
    
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handlePresetSelect = (preset: string) => {
    let newBands = [...localSettings.bands];
    
    // Apply different preset configurations
    switch (preset) {
      case 'bassBoost':
        // Boost low frequencies (bass)
        newBands = newBands.map((band, index) => {
          if (index < 3) {
            // Boost the first 3 bands (low frequencies)
            return { ...band, gain: 90 };
          } else if (index < 5) {
            // Midrange
            return { ...band, gain: 60 };
          } else {
            // Higher frequencies
            return { ...band, gain: 50 };
          }
        });
        break;
        
      case 'vocalBoost':
        // Boost mid frequencies (vocals)
        newBands = newBands.map((band, index) => {
          if (index > 2 && index < 7) {
            // Boost the middle bands (vocals usually in mid-range)
            return { ...band, gain: 80 };
          } else {
            // Lower the other frequencies
            return { ...band, gain: 50 };
          }
        });
        break;
        
      case 'trebleBoost':
        // Boost high frequencies (treble)
        newBands = newBands.map((band, index) => {
          if (index > 6) {
            // Boost the higher bands (treble)
            return { ...band, gain: 90 };
          } else if (index > 4) {
            // Upper midrange
            return { ...band, gain: 70 };
          } else {
            // Lower frequencies
            return { ...band, gain: 50 };
          }
        });
        break;
        
      default:
        break;
    }
    
    const newSettings = {
      ...localSettings,
      bands: newBands,
      presetName: preset
    };
    
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handleResetBands = () => {
    const newSettings = {
      ...DEFAULT_EQUALIZER_SETTINGS,
      presetName: 'Default'
    };
    
    setLocalSettings(newSettings);
    onChange(newSettings);
  };
  
  const handleSavePreset = () => {
    // In a real implementation, this would save the current EQ settings
    // as a user-defined preset. For now, we'll just set a preset name.
    const newSettings = {
      ...localSettings,
      presetName: 'Custom'
    };
    
    setLocalSettings(newSettings);
    onChange(newSettings);
    
    // This would typically involve a backend call to save the preset
    console.log("Saved custom preset:", newSettings);
  };
  
  return (
    <Card className={className}>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-5 flex items-center text-white">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-neon-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 11h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H2v8Z" />
            <path d="M2 21h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2H2v8Z" />
            <path d="M10 11h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-4v8Z" />
            <path d="M10 21h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-4v8Z" />
            <path d="M18 11h4V3h-4v8Z" />
            <path d="M18 21h4v-8h-4v8Z" />
          </svg>
          Equalizer
        </h2>
        
        <Equalizer 
          bands={localSettings.bands}
          onBandChange={handleBandChange}
          onPresetSelect={handlePresetSelect}
          onResetBands={handleResetBands}
          onSavePreset={handleSavePreset}
        />
      </CardContent>
    </Card>
  );
}

export default EqualizerPanel;
