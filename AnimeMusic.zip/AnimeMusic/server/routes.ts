import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { z } from "zod";
import { insertTrackSchema, insertPlaylistSchema, insertPlaylistTrackSchema } from "@shared/schema";

const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const uploadDir = path.join(process.cwd(), "uploads");
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      const ext = path.extname(file.originalname);
      cb(null, file.fieldname + "-" + uniqueSuffix + ext);
    },
  }),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes - prefix all with /api
  
  // Get all playlists
  app.get("/api/playlists", async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : undefined;
      const playlists = await storage.getPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      res.status(500).json({ message: "Failed to get playlists" });
    }
  });

  // Get a specific playlist with its tracks
  app.get("/api/playlists/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const playlist = await storage.getPlaylist(id);
      
      if (!playlist) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      
      const tracks = await storage.getPlaylistTracks(id);
      res.json({ ...playlist, tracks });
    } catch (error) {
      res.status(500).json({ message: "Failed to get playlist" });
    }
  });

  // Create a new playlist
  app.post("/api/playlists", async (req, res) => {
    try {
      const data = insertPlaylistSchema.parse(req.body);
      const playlist = await storage.createPlaylist(data);
      res.status(201).json(playlist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid playlist data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create playlist" });
    }
  });

  // Update a playlist
  app.patch("/api/playlists/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const data = req.body;
      const playlist = await storage.updatePlaylist(id, data);
      
      if (!playlist) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      
      res.json(playlist);
    } catch (error) {
      res.status(500).json({ message: "Failed to update playlist" });
    }
  });

  // Delete a playlist
  app.delete("/api/playlists/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const success = await storage.deletePlaylist(id);
      
      if (!success) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete playlist" });
    }
  });

  // Get all tracks (or search)
  app.get("/api/tracks", async (req, res) => {
    try {
      const query = req.query.q as string | undefined;
      
      if (query) {
        const tracks = await storage.searchTracks(query);
        return res.json(tracks);
      }
      
      // Since we don't have a getAll for tracks, just return an empty array
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Failed to get tracks" });
    }
  });

  // Create a track (from URL - YouTube, etc.)
  app.post("/api/tracks", async (req, res) => {
    try {
      const data = insertTrackSchema.parse(req.body);
      const track = await storage.createTrack(data);
      res.status(201).json(track);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid track data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create track" });
    }
  });

  // Upload an audio file
  app.post("/api/tracks/upload", upload.single("audioFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Create a track for the uploaded file
      const track = await storage.createTrack({
        title: req.body.title || path.basename(req.file.originalname, path.extname(req.file.originalname)),
        artist: req.body.artist || "Unknown Artist",
        duration: req.body.duration ? Number(req.body.duration) : 0,
        source: "local",
        sourceUrl: `/uploads/${req.file.filename}`,
        coverUrl: req.body.coverUrl || "",
      });
      
      res.status(201).json(track);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // Add a track to a playlist
  app.post("/api/playlists/:id/tracks", async (req, res) => {
    try {
      const playlistId = Number(req.params.id);
      
      // Check if playlist exists
      const playlist = await storage.getPlaylist(playlistId);
      if (!playlist) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      
      // Get current tracks to determine position
      const currentTracks = await storage.getPlaylistTracks(playlistId);
      const position = currentTracks.length;
      
      const data = insertPlaylistTrackSchema.parse({
        ...req.body,
        playlistId,
        position,
      });
      
      const playlistTrack = await storage.addTrackToPlaylist(data);
      res.status(201).json(playlistTrack);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add track to playlist" });
    }
  });

  // Remove a track from a playlist
  app.delete("/api/playlists/:playlistId/tracks/:trackId", async (req, res) => {
    try {
      const playlistId = Number(req.params.playlistId);
      const trackId = Number(req.params.trackId);
      
      const success = await storage.removeTrackFromPlaylist(playlistId, trackId);
      
      if (!success) {
        return res.status(404).json({ message: "Track not found in playlist" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove track from playlist" });
    }
  });

  // Reorder a track in a playlist
  app.patch("/api/playlists/:playlistId/tracks/:trackId/position", async (req, res) => {
    try {
      const playlistId = Number(req.params.playlistId);
      const trackId = Number(req.params.trackId);
      const { position } = req.body;
      
      if (typeof position !== "number") {
        return res.status(400).json({ message: "Position must be a number" });
      }
      
      const success = await storage.reorderPlaylistTrack(playlistId, trackId, position);
      
      if (!success) {
        return res.status(404).json({ message: "Track not found in playlist" });
      }
      
      res.status(200).json({ message: "Track reordered successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reorder track" });
    }
  });

  // Get user preferences
  app.get("/api/preferences/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const preferences = await storage.getUserPreferences(userId);
      
      if (!preferences) {
        return res.status(404).json({ message: "Preferences not found" });
      }
      
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to get preferences" });
    }
  });

  // Save user preferences
  app.post("/api/preferences", async (req, res) => {
    try {
      const preferences = await storage.saveUserPreferences(req.body);
      res.status(200).json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to save preferences" });
    }
  });

  // Serve uploads directory for local audio files
  app.use("/uploads", (req, res, next) => {
    // Check if the file exists
    const filePath = path.join(process.cwd(), "uploads", req.path);
    fs.access(filePath, fs.constants.F_OK, (err) => {
      if (err) {
        return res.status(404).json({ message: "File not found" });
      }
      next();
    });
  }, (req: Request, res: Response, next) => {
    // Set appropriate headers for audio files
    if (req.path.endsWith(".mp3")) {
      res.set("Content-Type", "audio/mpeg");
    } else if (req.path.endsWith(".wav")) {
      res.set("Content-Type", "audio/wav");
    } else if (req.path.endsWith(".ogg")) {
      res.set("Content-Type", "audio/ogg");
    }
    next();
  }, (req, res) => {
    // Serve the file
    const filePath = path.join(process.cwd(), "uploads", req.path);
    res.sendFile(filePath);
  });

  const httpServer = createServer(app);
  return httpServer;
}
